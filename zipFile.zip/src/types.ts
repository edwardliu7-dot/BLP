/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Activity {
  id: string;
  name: string;
  target: string;
}

export interface Category {
  id: string;
  name: string;
  label: string;
  activities: Activity[];
}

export interface DailyRecord {
  date: string; // ISO format date (YYYY-MM-DD)
  completedActivities: string[]; // List of activity IDs
  score?: number | null; // Teacher's score 0-100
}

export interface UserProgress {
  id: string;
  name: string;
  kelas: string;
  email: string;
  whatsapp: string;
  password?: string;
  records: Record<string, DailyRecord>;
}

export interface GuruProfile {
  id: string;
  name: string;
  kelasDiampu: string[];
  password?: string;
}

export interface SystemData {
  students: Record<string, UserProgress>;
  gurus: Record<string, GuruProfile>;
}

export type Role = 'siswa' | 'guru' | null;

export interface AuthState {
  role: Role;
  userId?: string;
  name?: string;
  kelas?: string;
  kelasDiampu?: string[];
}
